package DATABASE.ch3기본문법;

public class BuyDto {

	
	
	int num;
	String mem_id;
	String prod_name;
	String group_name;
	int price;
	int amount;
	
	
	
	public BuyDto() {
		
	}



	public BuyDto(int num, String mem_id, String prod_name, String group_name, int price, int amount) {
		super();
		this.num = num;
		this.mem_id = mem_id;
		this.prod_name = prod_name;
		this.group_name = group_name;
		this.price = price;
		this.amount = amount;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
